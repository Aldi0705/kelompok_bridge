import logo from './logo.svg';
import React, { Fragment } from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './layout/Layout';
{/*
import Main from './page/Main';
import About from './page/About';
import GuestBook from './page/Guestbook';
import Faq from './page/Faq';
import Askme from './page/Askme';
*/}

class App extends React.Component {
  render() {
    return (
      <Fragment>
        <Routes>
          <Route path="/" element={<Layout/>}>
            {/*
            <Route index element={<Main />}/>
            <Route path="about" element={<About />}/>
            <Route path="guest-book" element={<GuestBook />}/>
            <Route path="faq" element={<Faq />}/>
            <Route path="askme" element={<Askme />}/>
            */}
          </Route>
        </Routes>
      </Fragment>
    )
  }
}

export default App;
