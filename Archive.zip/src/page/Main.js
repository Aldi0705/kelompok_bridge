import React from "react";
import '../App.css';
import About from './About';
import Faq from './Faq';
import Contactus from './Contactus';

class Main extends React.Component {
    render() {
        return(
            <div className="homepage text-center">
                <h1 className="text-light display-3 pt-5"><strong>Welcome To <span style={{color:'#b8caff'}}>Bright Studio!</span></strong></h1>
                <h3 className="text-light pt-4">Do you like cool and professional looking photos and videos?</h3>
                <h4 className="text-light pt-1">You came to the right place!</h4>
                <About />
                <Faq />
                <Contactus />
            </div>
        )
    }
}
export default Main;