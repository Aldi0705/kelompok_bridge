import '../App.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import React from "react";
class Contactus extends React.Component {
    render() {
        return(
            <div className='card container1'>
                <h4>Contact Us</h4>
                <br></br>
                <Form>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label><h5>Your Name</h5></Form.Label>
                        <Form.Control type="text" placeholder="Enter Your Name" id="nama" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label><h5>Your Email</h5></Form.Label>
                        <Form.Control type="email" placeholder="Enter Your Email..." id="email" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label><h5>Subject</h5></Form.Label>
                        <Form.Control type="text" placeholder="Enter Your Subject..." id="subject"/>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                        <Form.Label><h5>Your Messege</h5></Form.Label>
                        <Form.Control as="textarea" rows={3} placeholder="Enter Your Messege" id="messege" />
                    </Form.Group>
                    <Button variant="primary" className='text5' onClick={() => this.handleClick()}>Submit</Button>
                    <p id='text'></p>
                </Form>
            </div>
        )
    }
}

export default Contactus;