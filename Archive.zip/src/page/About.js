import React, {Component} from "react";
import '../App.css';
import kenny from '../images/kenny.png'
import jeremi from '../images/jeremia.png'
import erwin from '../images/erwin.jpg'

class About extends React.Component {
    render() {
        return(
            <div className="other-contents">
                <h2 className='text-light'>About Us</h2>
                <section className='about card mt-5'>
                    <div className='container flex mtop'>
                        <div className='text'>
                            <img src={kenny} className='img-1'></img>
                        </div>
                        <div className='left row'>
                            <h4>I am Kenny Rimba</h4>
                            <h5>I am a professional videographer. I record cool shoots of your events.</h5>
                            <div className='data'>
                                <p>Full Name : Kenny Rimba</p>
                                <p>Age  : 20 Years Old</p>
                                <p>Specialization : Videography</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        )
    }
}
export default About;