import React from "react";
import questions from "./faq.json";
import Banner from "./banner";
export function Faq() {
  return (
    <Banner>
      <Banner.Header><span className="text-light">Frequently Asked Questions</span></Banner.Header>
      {questions.map((question) => (
        <Banner.Entity key={question.id}>
          <Banner.Question>{question.question}</Banner.Question>
          <Banner.Text>{question.answer}</Banner.Text>
        </Banner.Entity>
      ))}
    </Banner>
  );
}
export default Faq;