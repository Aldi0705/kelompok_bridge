import logo from './logo.svg';
import React, { Fragment } from 'react';
import { Routes, Route } from 'react-router-dom';
import Main from './page/Main';
import About from './page/About';
import Layout from './layout/Layout';
import Faq from './page/Faq';
import Contactus from './page/Contactus';

class App extends React.Component {
  render() {
    return (
      <Fragment>
        <Routes>
          <Route path="/" element={<Layout/>}>
            <Route index element={<Main />}/>
            <Route path="about" element={<About />}/>
            <Route path="faq" element={<Faq />}/>
            <Route path="contactus" element={<Contactus />}/>
          </Route>
        </Routes>
      </Fragment>
    )
  }
}

export default App;
