import React from "react";
import { Outlet, Link, NavLink} from "react-router-dom"
import { Routes, Route } from 'react-router-dom';
import '../App.css';
import logo from '../images/brand.png'
class Layout extends React.Component {
    render() {
        return (
        <div class="container-layout">
        <div class="vertical-nav leftsidebar bg-dark h-100" id="sidebar">
            <div class="logo-nav py-5 px-5 mb-5">
                <div class=" col-xs-1" align="center"><img src={logo} alt="..." width="160" class="align-items-center" />
                
                </div>
            </div>
            
            <div class="copyright col d-flex text-light justify-content-center">
                <p>&copy; 2022 <strong>BrightStudio</strong></p>
            </div>
            
        </div> 
        
        <div class="page-content w-100 h-100"><Outlet/></div>
        </div>
        )
    }
}

export default Layout;